package swipe;

public class Geeks_SwipNumbers {

	public static void main(String[] args) {
		
		int x = 10; 
        int y = 5; 
        x = x + y; 
        System.out.println("X value :"+x);
        y = x - y; 
        System.out.println("Y value :"+y);
        x = x - y; 
        System.out.println("After swapping:" + " x = " + x + ", y = " + y); 

	}

}
